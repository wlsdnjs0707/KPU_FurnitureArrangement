package kr.ac.kpu.ce2015154001.projectui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class recomm extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend);

        Button btnb = (Button) findViewById(R.id.btnback3);
        Button btnrot = (Button) findViewById(R.id.btnrotate);
        TextView classified = (TextView) findViewById(R.id.classified);
        TextView percent1 = (TextView) findViewById(R.id.percent1);
        TextView percent2 = (TextView) findViewById(R.id.percent2);
        ImageView imgsrc = (ImageView) findViewById(R.id.imgsrc);
        ImageView recimg1 = (ImageView) findViewById(R.id.recimg1);
        ImageView recimg2 = (ImageView) findViewById(R.id.recimg2);

        btnb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        btnrot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


    }
}
