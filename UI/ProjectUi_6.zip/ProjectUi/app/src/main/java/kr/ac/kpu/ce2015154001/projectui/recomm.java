package kr.ac.kpu.ce2015154001.projectui;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class recomm extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recommend);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        Button btnb = (Button) findViewById(R.id.btnback3);
        Button btnrot = (Button) findViewById(R.id.btnrotate);
        TextView classified = (TextView) findViewById(R.id.classified);
        TextView percent1 = (TextView) findViewById(R.id.percent1);
        TextView percent2 = (TextView) findViewById(R.id.percent2);
        ImageView imgsrc = (ImageView) findViewById(R.id.imgsrc);
        ImageView recimg1 = (ImageView) findViewById(R.id.recimg1);
        ImageView recimg2 = (ImageView) findViewById(R.id.recimg2);
        ImageView recimg3 = (ImageView) findViewById(R.id.recimg3);
        ImageView recimg4 = (ImageView) findViewById(R.id.recimg4);
        ImageView recimg5 = (ImageView) findViewById(R.id.recimg5);
        int imgcount =3;
        String imguri1, imguri2, imguri3, imguri4, imguri5;
        recimg2.setVisibility(View.GONE);
        recimg3.setVisibility(View.GONE);
        recimg4.setVisibility(View.GONE);
        recimg5.setVisibility(View.GONE);

        while(imgcount>0) {
            switch (imgcount) {
                case 1:
                    recimg1.setVisibility(View.VISIBLE);
                    break;
                case 2:
                    recimg2.setVisibility(View.VISIBLE);
                    break;
                case 3:
                    recimg3.setVisibility(View.VISIBLE);
                    break;
                case 4:
                    recimg4.setVisibility(View.VISIBLE);
                    break;
                case 5:
                    recimg5.setVisibility(View.VISIBLE);
                    break;
            }
            imgcount--;
        }
        btnb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        btnrot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });


    }
}
