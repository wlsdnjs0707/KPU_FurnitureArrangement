package kr.ac.kpu.ce2015154001.projectui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Button btnexit=(Button) findViewById(R.id.btnexit);
        Button btnplace=(Button) findViewById(R.id.btnplace);
        Button btnrecom=(Button) findViewById(R.id.btnrecom);
        ImageView mainimg = (ImageView) findViewById(R.id.mainimg);

        btnexit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveTaskToBack(true);
                finishAndRemoveTask();
                System.exit(0);
            }
        });
        btnplace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        btnrecom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentp = new Intent(getApplicationContext(), informed.class);
                startActivity(intentp);
            }
        });

    }


}
