package kr.ac.kpu.ce2015154001.projectui;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.time.Instant;

public class checkpic extends Activity {
    private static final String TAG = "TEST";
    private final int REQ_CODE_SELECT_IMAGE = 1001;
    private final int REQUEST_IMG_CODE = 1001;
    private String mImgPath = null;
    private String mImgTitle = null;
    private String mImgOrient = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.checkinterior);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
        { if(checkSelfPermission(Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        == PackageManager.PERMISSION_GRANTED) { Log.d(TAG, "권한 설정 완료"); }
        else { Log.d(TAG, "권한 설정 요청");
            ActivityCompat.requestPermissions(checkpic.this,
                    new String[]{Manifest.permission.CAMERA,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1); } }



        Button btnb = (Button) findViewById(R.id.btnback1);
        Button btng = (Button) findViewById(R.id.btngallery);
        Button btnp = (Button) findViewById(R.id.btnpic);




        btnb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               finish();
            }
        });

        btng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getGallery();
            }
        });
        btnp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), recomm.class);
                startActivity(intent);
//                takePicture();
            }
        });

    }
//    private void takePicture(){
//        Intent cameraintent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//            startActivityForResult(cameraintent,REQUEST_IMG_CODE);
//
//
//    }
    private void getGallery()
    {
        Intent intent = null;
            intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent.setType("image/*");
            startActivityForResult(intent, REQ_CODE_SELECT_IMAGE);
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if(requestCode==REQ_CODE_SELECT_IMAGE)
        {
            if(resultCode==Activity.RESULT_OK)
            {
                Uri uri = data.getData();
                getImageNameToUri(uri);

                try{
                    Bitmap bm = MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
                    ImageView selected = (ImageView) findViewById(R.id.selimg);
                    selected.setImageBitmap(bm);
                }
                 catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void getImageNameToUri(Uri data) {
        String[] proj = {
                MediaStore.Images.Media.DATA,
                MediaStore.Images.Media.TITLE,
                MediaStore.Images.Media.ORIENTATION
        };

        Cursor cursor = this.getContentResolver().query(data, proj, null, null, null);
        cursor.moveToFirst();

        int column_data = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        int column_title = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.TITLE);
        int column_orientation = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.ORIENTATION);

        mImgPath = cursor.getString(column_data);
        mImgTitle = cursor.getString(column_title);
        mImgOrient = cursor.getString(column_orientation);
    }




}
