package kr.ac.kpu.ce2015154001.projectui;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.Nullable;

public class recomm extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.checkinterior);
    }
    Button btnb = (Button) findViewById(R.id.btnback1);
    Button btng = (Button) findViewById(R.id.btngallery);
    Button btnp = (Button) findViewById(R.id.btnpic);
    Button btnr = (Button) findViewById(R.id.btnrec);


}
